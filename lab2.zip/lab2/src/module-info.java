/**
 * 
 */
/**
 * @author Quant
 *
 */
module lab2 {
}